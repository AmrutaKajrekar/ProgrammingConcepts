My approach:

1) if input is empty then return 0
2) if input length has 1 element the return the element value because that is the only house we are going to rob.
3) if input has 2 elements, return the max of them
4) for all the inputs above length 2, do the following:
    -create an array named robbed having all the amount robbed for the houses selected at each iteration
    -started from 1st house till second to last house, we'll select the max value of alternate houses and choose the once with higher value
    -for the last house, we need to decide to rob it, only if the first house was not selected for robbing.
    -for this keep a boolean - true if first house was robbed or false if not.
    -if first house was robbed, we cannot select the last element
    -But if the max is greater than the robbed houses, we have to iterate again but this time from the last element till second element.


    For instance, see input= 100,2,3,100,3
    Output will be = 200
    But for input = 100,2,3,100,500, the last element is the highest value
    so Output will be = 503



