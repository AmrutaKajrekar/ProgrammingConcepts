package helper;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.util.ArrayList;

public class Helper {

    public int[] parseJsonFile(String s) {
        System.out.println(this.getClass().getResource(s));
        JSONParser parser = null;
        ArrayList<Integer> list = new ArrayList<Integer>();
        try {
            parser = new JSONParser();

            InputStreamReader reader = new InputStreamReader(this.getClass().getResourceAsStream(s));
            JSONArray array = (JSONArray) parser.parse(reader);
            for(int i=0;i<array.size();i++){
                list.add(Integer.parseInt((((JSONObject)array.get(i)).get("value")).toString()));
            }
        } catch (FileNotFoundException e) {
            System.out.print("File not found. Please check input at location " + s);
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (EOFException e){
            System.out.print("Empty JSON file. Please check input at location " + s);
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }

        int[] nums = new int[list.size()];
        System.out.println("\nReading the json file values:");
        for (int i = 0; i < nums.length; i++) {
            nums[i] = list.get(i);
            if(i== nums.length -1) {
                System.out.print(nums[i]);
            }
            else{
                System.out.print(nums[i]+",");
            }
        }
        return nums;
    }
}
