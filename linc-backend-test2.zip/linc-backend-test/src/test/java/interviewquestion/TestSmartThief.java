package interviewquestion;

import helper.Helper;
import org.junit.Assert;
import org.junit.Test;

public class TestSmartThief {

    @Test
    public void testRobbingPlan(){

        SmartThief thief = new SmartThief();
        Helper helper = new Helper();

        int received = thief.robbingPlan(helper.parseJsonFile("/input.json"));
        System.out.println("received value = "+ received);
        Assert.assertEquals(27461,received);
    }

    @Test
    public void testRobbingPlanForEmptyInput(){

        SmartThief thief = new SmartThief();
        Helper helper = new Helper();

        int received = thief.robbingPlan(helper.parseJsonFile("/empty.json"));
        System.out.println("received value = "+ received);
        Assert.assertEquals(0,received);
    }


    @Test
    public void testRobbingPlanForSmallInput(){

        SmartThief thief = new SmartThief();
        Helper helper = new Helper();

        //100,2,3,100,3: expected is: 200
        //100,500,3,100,3: expected is: 600
        int received = thief.robbingPlan(helper.parseJsonFile("/smallinput.json"));
        System.out.println("received value = "+ received);
        Assert.assertEquals(200,received);
    }
}

