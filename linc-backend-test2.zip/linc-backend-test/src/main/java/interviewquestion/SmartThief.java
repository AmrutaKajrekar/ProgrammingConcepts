package interviewquestion;

import helper.Helper;

/**
 * input:
 * [856,114,485,553,123,340,108,605,747,790,439,778,842,515,350,696,885,489,392,394,893,946,886,612,704,160,999,312,591,401,170,991,711,418,714,992,890,651,221,140,827,372,717,960,125,272,113,526,267,495,947,305,327,564,731,729,623,613,9,75,104,397,952,228,120,994,667,652,523,159,623,749,450,365,786,657,66,557,747,419,888,317,686,363,385,792,41,211,360,328,130,12,45,558,107,173,114,36,157,631]
 *
 */
public class SmartThief {

    public static void main(String[] args){
        SmartThief thief = new SmartThief();
        Helper helper = new Helper();

        int[] nums = new int[]{};
//        int[] nums = new int[]{101,501,502,3,50}; //502+101 = 603

        nums = helper.parseJsonFile("/input.json");
        System.out.println("\ntotal robbed money="+ thief.robbingPlan(nums));
    }


    public int robbingPlan(int[] num) {

        if (num.length == 0)
            return 0;
        if (num.length == 1)
            return num[0];
        if (num.length == 2)
            return Math.max(num[0], num[1]);

        if (num.length > 2) {
            //calculate how much we robbed until i th index.
            int[] robbed = new int[num.length + 1];
            robbed[0] = num[0];
            robbed[1] = Math.max(num[0], num[1]);
            boolean house1Robbed = false;
            int result = 0;

            //compare with last 2, whichever is max, add to the robbed index
            for (int i = 2; i < num.length-1; i++) {
                int max1= robbed[i - 2] + num[i];
                int max2= robbed[i - 1];

                robbed[i] = Math.max(max1, max2);

                if(i==2 && max1 >max2){
                    house1Robbed = true;
                }
                result = robbed[i];
            }
            int i=num.length-1;
            if(!house1Robbed){
                int max1= robbed[i - 2] + num[i];
                int max2= robbed[i - 1];

                robbed[i] = Math.max(max1, max2);
                result = robbed[i];
            }else {
                if (num[i] > result){
                    int[] newRobbed = new int[num.length];
                    newRobbed[num.length - 1] = num[num.length - 1];
                    newRobbed[num.length - 2] = Math.max(num[num.length - 1], num[num.length - 2]);
                    int j = num.length - 3;
                    for (; j > 0; j--) {
                        int max1 = newRobbed[j + 2] + num[j];
                        int max2 = newRobbed[j + 1];

                        newRobbed[j] = Math.max(max1, max2);

                        result = newRobbed[j];
                    }
                    return result;
                }else{
                    Math.max(result, num[i]);
                }
            }
            //return the last robbed index which will be the total robbed amount
            return result;
        }
        return -1;
    }
}
