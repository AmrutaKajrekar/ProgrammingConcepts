package helper;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Helper {

    public int[] parseJsonFile(String s) {
        System.out.println(this.getClass().getResource(s));
        JSONParser parser = null;
        ArrayList<Integer> list = new ArrayList<Integer>();
        try {
            parser = new JSONParser();

            JSONArray array = (JSONArray) parser.parse(new FileReader(getClass().getResource(s).getFile()));
            for(int i=0;i<array.size();i++){
                list.add(Integer.parseInt((((JSONObject)array.get(i)).get("value")).toString()));
            }
        } catch (FileNotFoundException e) {
            System.out.print("File not found. Please check input at location " + s);
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (EOFException e){
            System.out.print("Empty JSON file. Please check input at location " + s);
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }

        int[] nums = new int[list.size()];
        for (int i = 0; i < nums.length; i++) {
            nums[i] = list.get(i);
            System.out.print(nums[i]+",");
        }
        return nums;
    }
}
